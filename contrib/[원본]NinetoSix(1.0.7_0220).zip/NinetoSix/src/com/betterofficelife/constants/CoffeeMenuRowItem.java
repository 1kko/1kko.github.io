package com.betterofficelife.constants;

public class CoffeeMenuRowItem {

	private String menuName;


	public CoffeeMenuRowItem(String menuName) {
	
		this.menuName = menuName;

	}


	public String getName() {
		return menuName;
	}
	public void setName(String menuName) {
		this.menuName = menuName;
	}
	
	
}