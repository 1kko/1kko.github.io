/** Automatically generated file. DO NOT MODIFY */
package com.betterofficelife.ninetosix;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}